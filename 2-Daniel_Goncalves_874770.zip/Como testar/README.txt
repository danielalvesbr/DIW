Opa tranquilo?

Aq, pra testar abre essa pasta acima e vai em public, depois em index.html.
Abre a pasta index.html no live server q vai dar tudo certo.

caminho: 2-Daniel_Goncalves_874770\public\index.html

TMJ :)
